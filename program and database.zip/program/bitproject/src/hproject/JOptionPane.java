/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hproject;

/**
 *
 * @author GuHeHe
 */
class JOptionPane {

    static void showMessageDialog(PromoSearch aThis, String please_choose_Type_Name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
